
import pandas as pd

def get_words_burberry(link):
    return link.replace("/", "").split("-")
    
def get_words_versace(link):
    if link.startswith("/us/en-us/women/new-arrivals/new-in/?"):
        return []
    words = link.replace("/us/en-us/women/new-arrivals/new-in/", "") .split("/")
    words = words[0].split("-")
    return words
    
def get_words_dg(link):
    return link.replace("Visit", "").replace(" product page","").split(" ")
    
def get_word_counts_dict(docs, brand, threshold, get_words_fn):
    # input: list of documents []
    # output: pandas dataframe of words and counts
    result = {}
    for link in docs:
        words = get_words_fn(link)
        for word in words:
            if word in result:
                result[word] += 1
            else:
                result[word] = 1
                
    words = list(result.keys())
    counts = list(result.values())

    # turn dictionary into the dataframe
    df = pd.DataFrame.from_dict({
        "words": words,
        "counts": counts,
    })
    
    df = df.sort_values("counts", ascending = True) # sorting
    df['brand'] = brand # add brand
    df = df[df['counts'] > threshold] # get subset reaching the threshold
    return df