from bs4 import BeautifulSoup
import requests

def add_burberry(docs, link):
    l = link.get("href")
    if "-p80" in l: # todo: change
        docs.append(l)
        
def add_versace(docs, link):
    l = link.get("href")
    if l.startswith("/us/en-us/women/new-arrivals/new-in/"):
        docs.append(l)
        
def add_dg(docs, link):
    l = link.get("aria-label")
    if l != None and l.startswith("Visit"):
        docs.append(l)

def scrap_links(urls, add_fn):
    # scraps urls and creates a list of documents
    # input: list of urls []
    # output: list of docs []
    
    docs = []
    for url in urls:
        r = requests.get(url)
        html_doc = r.text
        soup = BeautifulSoup(html_doc)

        for link in soup.find_all("a"):
            add_fn(docs, link)
                
    docs = set(docs) # get unique documents
    print("Number of unique items:" + str(len(docs)))
                
    return docs