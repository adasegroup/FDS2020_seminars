
import pandas as pd

from sklearn.dummy import DummyClassifier
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier

def brand_target(brand):
    if 'versace' in brand:
        val = 0
    elif 'burberry' in brand:
        val = 1
    elif 'd&g' in brand:
        val = 2
    else:
        raise ValueError(f'Invalid brand: {brand}')
    return val

def prepare_df(df_versace, df_burberry, df_dg):
    # Create whole dataframe
    df_brands = pd.concat([df_versace.reset_index(), df_burberry.reset_index(), df_dg.reset_index()])
    df_brands = df_brands.drop(columns=['index'])
    df_brands['words'] = df_brands['words'].str.upper()
    
    X = pd.get_dummies(df_brands['words']).values # get one hot encoded
    y = df_brands['brand'].apply(brand_target).values
    return X, y

def create_classifiers():
    models = []
    models.append(("Baseline", DummyClassifier(random_state=391488407)))
    models.append(("Support vector (C=1.00)", SVC(C=1.00, gamma="scale")))
    models.append(("Support vector (C=0.25)", SVC(C=0.25, gamma="scale")))
    models.append(("Support vector (C=4.00)", SVC(C=4.00, gamma="scale")))
    models.append(("Random Forest", RandomForestClassifier(n_estimators=100, random_state=1283220422)))
    models.append(("Logistic Regression (C=1.00)", LogisticRegression(C=1.00, solver="liblinear", penalty="l1")))
    models.append(("Logistic Regression (C=0.25)", LogisticRegression(C=0.25, solver="liblinear", penalty="l1")))
    models.append(("Logistic Regression (C=4.00)", LogisticRegression(C=4.00, solver="liblinear", penalty="l1")))
    models.append(("1-nn euclidean", KNeighborsClassifier(n_neighbors=1)))
    models.append(("1-nn cosine", KNeighborsClassifier(n_neighbors=1, metric="cosine")))
    models.append(("5-nn cosine", KNeighborsClassifier(n_neighbors=5, metric="cosine")))
    models = dict(models)
    return models
    
def train_models(models, X_train, X_test, y_train, y_test):
    for name, clf in models.items():
        clf.fit(X_train, y_train)
    scores = pd.Series({name: clf.score(X_test, y_test) for name, clf in models.items()}, name="Accuracy")
    return scores