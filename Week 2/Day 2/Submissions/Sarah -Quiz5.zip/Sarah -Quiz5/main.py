import argparse

import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split

from extract import get_words_burberry, get_words_versace, get_words_dg, get_word_counts_dict
from scraping import scrap_links, add_burberry, add_versace, add_dg
from modelling import create_classifiers, train_models, prepare_df

def open_file(filename):
    links = []
    with open(filename, 'r+') as file:
        for line in file.read().splitlines():
            links.append(line)
    return links

def cmdline_args():
    # Make parser object to use arguments from terminal
    parser = argparse.ArgumentParser()
    parser.add_argument('--urls-burberry', help='burberry links to scrap')
    parser.add_argument('--urls-versace', help='versace links to scrap')
    parser.add_argument('--urls-dg', help='d&g links to scrap')
    return parser.parse_args()   

    
def plot_save(df, title, color, savename):
    plt.barh(df['words'], df['counts'], color =color)
    plt.title(title)
    plt.savefig(savename)
    

def main(args):
    # get urls
    urls_burberry = args.urls_burberry
    urls_versace = args.urls_versace
    urls_dg = args.urls_dg
    
    urls_burberry_list = open_file(urls_burberry)
    urls_versace_list = open_file(urls_versace)
    urls_dg_list = open_file(urls_dg)
    
    ## burbery processing
    docs_burbey = scrap_links(urls_burberry_list, add_burberry)
    df_burberry = get_word_counts_dict(docs_burbey, 'burberry', 3, get_words_burberry)
    plot_save(df_burberry, "Most used words in Burberry 'New in' SS2020 Women collection", "#C19A6B", 
              "SS2020_Burberry_word_frequency.jpg")
              
    ## versace processing
    docs_versace = scrap_links(urls_versace_list, add_versace)
    df_versace = get_word_counts_dict(docs_versace, 'versace', 2, get_words_versace)
    plot_save(df_versace, "Most used words in Versace 'New in' SS2020 Women collection", "#FFD700", 
              "SS2020_Versace_word_frequency.jpg")
              
    ## d&g processing
    docs_dg = scrap_links(urls_dg_list, add_dg)
    df_dg = get_word_counts_dict(docs_dg, 'd&g', 4, get_words_dg)
    plot_save(df_dg, "Most used words in D&G 'New in' SS2020 Women collection", "#E0115F", 
              "SS2020_D&G_word_frequency.jpg")
              
    # Prepare data
    X, y = prepare_df(df_versace, df_burberry, df_dg)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.33, random_state=42)
    
    ## Modelling
    models = create_classifiers()
    scores = train_models(models, X_train, X_test, y_train, y_test)
    scores.to_csv('results.csv') # save scores

if __name__ == '__main__':
    args = cmdline_args()
    main(args)